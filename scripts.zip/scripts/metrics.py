from sklearn.metrics import mean_squared_log_error

__doc__ == mean_squared_log_error.__doc__