|    | entities      |       error |
|---:|:--------------|------------:|
|  0 | Store_id      | 6.29257e-05 |
|  1 | Store_Type    | 4.09545     |
|  2 | Location_Type | 1.02877     |
|  3 | Region_Code   | 2.32491     |